

<?php $__env->startSection('content'); ?>

<div>
    <h1 class="text-3xl text-center">Welcome to the Dashboard</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ulo_project\resources\views/welcome.blade.php ENDPATH**/ ?>
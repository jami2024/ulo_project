

<footer class="bg-white py-2">
    <div class="lg:flex items-center justify-between px-8">
        <div class="flex items-center gap-2">
           <a href=""> <img class="" src="{{ asset('assets/backend/img/montolaloy.png') }}" alt=""></a>
            <h4 class="font-ubontu text-12  text-black leading-5">ভূমি ব্যবস্থাপনা অটোমেশন, গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</h4>
        </div>

        <div class="flex items-center gap-2">
            <h4 class="font-ubontu text-12 leading-3 text-black">কারিগরি সহায়তায়</h4>
            <a href=""> <img class="" src="{{ asset('assets/backend/img/company.png') }}" alt=""></a>
        </div>
    </div>

</footer>
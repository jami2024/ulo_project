@extends('layout.backend_master')

@section('content')

<div>
    <h1 class="text-3xl text-center">Welcome to the Dashboard</h1>
</div>
@endsection